import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  

  constructor(private fb:FormBuilder) { }
  customer_details=this.fb.group({
    username:['',Validators.required],
    email:['',Validators.required],
    phone_no:['',Validators.required]
  })
  onSubmit(){
    console.log(this.customer_details.value)
  }
  ngOnInit(): void {
  }

}
