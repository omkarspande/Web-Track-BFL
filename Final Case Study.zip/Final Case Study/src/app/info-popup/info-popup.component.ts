import { Component, Input, OnInit } from '@angular/core';


@Component({
  selector: 'app-info-popup',
  templateUrl: './info-popup.component.html',
  styleUrls: ['./info-popup.component.css']
})
export class InfoPopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
