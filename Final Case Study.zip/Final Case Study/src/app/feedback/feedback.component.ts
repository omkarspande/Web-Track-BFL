import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  
  feedback_sub_flag:boolean
  constructor(private fb:FormBuilder) { }
  feedback_details=this.fb.group({
    customer_name:['',Validators.required],
    customer_contact:['',Validators.required],
    customer_comment:['',Validators.required]
  })

  onSubmit(){
    console.log(this.feedback_details.value)
    this.feedback_sub_flag=true
    
  }
  ngOnInit(): void {
  }

}
