import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  message: any
  title = 'sample-app';
  registered: boolean = false
  user_not_registered:boolean
  processed:boolean
  // user_status:boolean
  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router, config: NgbModalConfig, private modalService: NgbModal) {
    http.get("http://localhost:3000/", { responseType: 'json' }).subscribe(observer => {
      this.message = observer
    })
    config.backdrop = 'static';
    config.keyboard = false;
  }

  userdetails1: {
    'username': '',
    'password': '',
    'email':'',
    'phone':'',
    'address':''
  } = {
      'username': '',
      'password': '',
      'email':'',
      'phone':'',
      'address':''

    }

  userdetails2: {
    'username': '',
    'password': ''
  } = {
      'username': '',
      'password': ''

    }
  validated: boolean = false

  token: { 'token': "" } = { 'token': '' }


  register() {

    this.http.post("http://localhost:3000/register", { username: this.userdetails1.username, password: this.userdetails1.password ,email:this.userdetails1.email,phone:this.userdetails1.phone,address:this.userdetails1.address}, { responseType: 'json' }).subscribe(observer => {
      this.token = observer as { 'token': '' }
      // this.user_status = observer as boolean
      this.registered = true
    })
  }
  login() {
    this.http.post("http://localhost:3000/login", this.token, { responseType: 'json' }).subscribe(observer => {
      console.log(observer)
      if (observer) {
        console.log('authenticated')
        if(this.userdetails1.username == this.userdetails2.username && this.userdetails1.password == this.userdetails2.password){
          this.validated = true
        }
        this.router.navigateByUrl("/")
      }

    }
    )

  }

  logout() {
    this.validated = false
  }
  generatepost() {
    console.log('post received')
    this.http.post("http://localhost:3000/", { 'name': 'black cofee', 'price': 300 }, { responseType: 'text' }).subscribe(observer => {
      console.log(observer)
    })
  }
  open(content) {
    this.modalService.open(content)
  }


}
