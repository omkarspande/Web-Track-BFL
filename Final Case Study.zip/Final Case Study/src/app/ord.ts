export class ord{
    name:String
    price:number
}