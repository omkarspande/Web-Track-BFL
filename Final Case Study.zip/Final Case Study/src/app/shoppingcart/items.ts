export class Items{
    name:string
    price:number
}