import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ord } from '../ord';


@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent implements OnInit {
  message:any
  selected_items: ord[]
  localItem: any;

  constructor() {
    this.localItem = localStorage.getItem("selected_items");
    if (this.localItem == null) {
      this.selected_items = [];
    }
    else {
      this.selected_items = JSON.parse(this.localItem)
    }
  }

  ngOnInit(): void {
  }
  add_item(b:ord){
    this.selected_items.push(b)
    console.log(b)
    // localStorage.setItem("selected_items", JSON.stringify(this.selected_items));
  }
  



}
