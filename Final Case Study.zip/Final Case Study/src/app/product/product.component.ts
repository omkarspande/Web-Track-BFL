import { Content } from '@angular/compiler/src/render3/r3_ast';
import { Component, Input, OnInit, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { ordered_item, product_list_clothes, product_list_electronics, product_list_stationary } from './productlist';
import { Router } from '@angular/router';
import { EventEmitter } from '@angular/core';
import { ord } from '../ord';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @Output() addItem: EventEmitter<ord> = new EventEmitter();
  message: any
  pro_sel:string
  pro_category:string
  name:string
  gofor:string
  msgtochild:string
  pro_list_electronics=product_list_electronics
  pro_list_clothes=product_list_clothes
  pro_list_stationary=product_list_stationary
  
  constructor(config: NgbModalConfig, private modalService: NgbModal,private http: HttpClient, private router: Router) {
    http.get("http://localhost:3002/", { responseType: 'json' }).subscribe(observer => {
      this.message = observer
    })
    // customize default values of modals used by this component tree
    config.backdrop = 'static';
    config.keyboard = false;
  }

  open(content) {
    this.modalService.open(content);
  }

  onSelect(value:string){
    this.gofor=value
  }

  open_sta(stationary)
  {
    this.modalService.open(stationary)
  }
  open_ele(electronics)
  {
    this.modalService.open(electronics)
  }
  open_clo(clothes)
  {
    this.modalService.open(clothes)
  }

  product_selected(string){
  

  }

  add_to_cart(val:string){
    console.log(val)
    const order = {
      name:val,
      price:100

    }
 
    this.addItem.emit(order)
    this.http.post("http://localhost:3002/cart", order, { responseType: 'json' }).subscribe(observer => {
      console.log(observer)
      
    })

  }
  ngOnInit(): void {
  }

}


