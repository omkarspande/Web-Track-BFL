class product{
  
    name:string
}
export class ordered_item{
    name:string
    price:number
}
export const product_list_electronics:product[]=[
    {
        name:'none'
    },
    {
      
        name:'apple'
    },
    {
    
        name:'redmi'
    },
    {
  
        name:'poco'
    },
    {
       
        name:'nord2'
    },
    {
    
        name:'lenovo'
    },
    {
      
        name:'hp'
    },
    {
     
        name:'ipad'
    },
    {
      
        name:'iwatch'
    },
    {
     
        name:'macbook'
    },
    
    {
     
        name:'samsung'
    }
     
]

export const product_list_clothes:product[]=[
    {
        name:'none'
    },
    {
      
        name:'Jacket'
    },
    {
    
        name:'Cap'
    },
    {
  
        name:'Shoes'
    },
    {
       
        name:'T-shirt'
    },
    {
    
        name:'Shirt'
    },
    {
      
        name:'Formal Suit'
    },
    {
     
        name:'Trackers'
    },
    {
      
        name:'Shorts'
    },
    {
     
        name:'Nike Shoes'
    },
    
     
]

export const product_list_stationary:product[]=[
    {
        name:'none'
    },
    {
      
        name:'Book'
    },
    {
    
        name:'Crayons'
    },
    {
  
        name:'Pen'
    },
    {
       
        name:'Marker'
    },
    {
    
        name:'Pencil'
    },
    {
      
        name:'Compass Box'
    },
    {
     
        name:'School Bag'
    },
    {
      
        name:'Sketch Pen'
    },
    {
     
        name:'Scissors'
    },
    
    {
     
        name:'Sello Tape'
    }
     
]
